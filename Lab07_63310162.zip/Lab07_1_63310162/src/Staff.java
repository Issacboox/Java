public class Staff {
String firstName;
String lastName;
String ID;
//assign the properties of String ID.

//create a constructor for this Staff class with three arguments firstName,lastName, and ID.
public Staff(String firstName ,String lastName,String ID){
//assign input arguments to their corresponding class properties.
this.firstName = firstName ;
this.lastName =lastName;
this.ID =ID; }
void printStaffInfo() {
System.out.println( "Mr/Ms: " + firstName + " " + lastName + "ID :" + ID);
}
}