public class Salary {
int salary; 
//create a constructor for this Salary class with one argument: salary.
public Salary ( int salary ) {
//assign input arguments to their corresponding class properties.
this.salary = salary;
}
void staffSalary() {
System.out.println("Will get the amount of salary of " + salary);
}
}