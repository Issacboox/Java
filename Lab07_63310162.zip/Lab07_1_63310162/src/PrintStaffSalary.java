public class PrintStaffSalary {
public static void main(String[] args) {
Staff staff = new Staff("Jame", "Smith", "2020111");
Salary salary = new Salary(500);
salary.staffSalary();
// by using dot operator, print out the staffSalary.
staff.printStaffInfo();
 ;
 }
}