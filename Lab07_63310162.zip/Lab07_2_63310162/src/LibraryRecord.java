public class LibraryRecord {
public static void main(String[] args) {
StudentInformation studentInfo = new StudentInformation("Johan","Son",612204011);
BookInformation bookInfo = new BookInformation("How to win friends & Influence people"," VP2020");
BorrowDate borrowDate = new BorrowDate("22", "February", "2021");
//Using dot operator, print out the printStudentInformation.
studentInfo.printStudentInformation() ;
bookInfo.printBookInformation();
borrowDate.printBorrowDate();
 }
}