public class BorrowDate {
String day, month, year;
public BorrowDate(String day, String month, String year) {
this.day = day;
this.month = month;
this.year = year; }
void printBorrowDate() {
System.out.println("Borrow date: " + day + "/" + month + "/"  + year);

 }
}