public class StudentInformation {
String firstName ;
String lastName;
int ID ;
//assign the properties of int ID.

//create a constructor for this StudentInformation class with three arguments,
public StudentInformation(String firstName,String lastName,int ID ) {
//assign input arguments to their corresponding class properties.
this.firstName=firstName ;
this.lastName = lastName;
this.ID = ID;
 }
void printStudentInformation() {
System.out.println("Student's name: " + firstName + " " + lastName);
System.out.println("ID number:" + ID);
 }
}