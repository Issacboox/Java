public class BookInformation {
String bookTitle;
String bookCode;
//create a constructor for this BookInformation class with two arguments
public BookInformation(String bookTitle,String bookCode ){
//assign input arguments to their corresponding class properties.
this.bookTitle = bookTitle;
this.bookCode = bookCode;
 }
void printBookInformation() {
System.out.println("Book's Title: " + bookTitle);
System.out.println("Book's Code: " + bookCode);
 }
}