import java.util.Scanner;
public class MyTest2 {
	public static void main (String[]args) 
	{
		int n,sum=0;
		try(Scanner scan = new Scanner(System.in)){
		System.out.println("How many number would you like to add ? :");
		n = scan.nextInt();
		
		int a[]=new int[n]; 
	    System.out.println("enter the "+n+" numbers ");
                   for(int i=0;i<n;i++)
                   {      
	             System.out.println("enter number : "+(i+1)+":");
                           a[i]=scan.nextInt();
                   }
                   for(int i=0;i<n;i++)
                   {
                           sum+=a[i];
                   }  	    
                   System.out.println("sum of "+n+" numbers is ="+sum);                  
              	}
           } 
	
        }

