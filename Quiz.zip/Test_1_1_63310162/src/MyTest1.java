import java.util.Scanner;
public class MyTest1 {
    public static void main (String[]args) {
    	try(Scanner scan = new Scanner(System.in)){
    		System.out.println("How many row would you like to print ? :");
    		int row = scan.nextInt() ;
    		
    		for (int i=0;i<row ;i++) {
    			for (int j = 0 ;j<=i;j++) {
    				System.out.print("#");
    			}
    			System.out.println();
    		}
    		for (int i=row-1;i>=0;i--) {
    			for (int j = 0 ;j<=i;j++) {
    				System.out.print("*");
    			}
    			System.out.println();
    		}
    	}
    }
}
