public class Person {
static String name = "Nurarat Sangreuang"; //ไม่มีคำว่า static
static int numPerson=0;
Person(String name) {
Person.name=name;
numPerson++;
}
void sayGoodbye()
{
System.out.println("Good Bye" + name);
}
void hiBye()
{
sayHello();
sayGoodbye();
}
static void sayHello() {
System.out.println("Hello");
}
static void sayHi() {
System.out.println("Hi" + name);
}
public static void main(String [] args)
{
System.out.println(name);
System.out.println(Person.numPerson);
Person.sayHello();
}
}