
public class FamilyMember {
public static String familyName = "Hilton" ;
String firstName ;
public static double commonFund = 100000 ;
double privateFund ;

public FamilyMember (String firstName, double privateFund) {
	this.firstName = firstName ;
	this.privateFund = privateFund ;
}
void printPrivateFund() { 
	System.out.println (firstName +" " +  familyName + " has $" + privateFund);
}
void contributeToCommonFund(double amount) {
	privateFund = privateFund - amount;
	commonFund = commonFund + amount;
}
static void payFromCommonFund(double amount) {
	commonFund = commonFund - amount;
}
static void printFamilyFund() {
	System.out.println("The " + familyName + " family has $" + commonFund);
}
}
