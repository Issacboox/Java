
public class Circle {
     int radius;
     
     public Circle(int r) {
    	 radius = r ;
     }
     public int getDiameter() {
    	 return radius * 2 ;
     }
     void printCircleInfo() {
    	 System.out.println(" The circle has a daimeter of " + getDiameter());
     }
}
