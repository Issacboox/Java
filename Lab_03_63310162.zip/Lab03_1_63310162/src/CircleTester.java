
public class CircleTester {
    public static void main(String[]ards) {
    	Circle myCircle = new Circle(25);
    	myCircle.printCircleInfo();
    }
}
