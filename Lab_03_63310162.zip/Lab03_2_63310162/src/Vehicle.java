
public class Vehicle {
   int speed = 0 ;
   String vehicleName ;
   public void enrollVehicle(String name) {
	   vehicleName = name;
   }
   void accelerate() {
	   speed = speed+100;
   }
   void applyBreak() {
	   speed = speed-50;
   }
   void printCurrentSpeed() {
	   System.out.println("The speed of your "+  vehicleName  +
	   " is "+ speed +" Km per hour.");
	   }
	   }