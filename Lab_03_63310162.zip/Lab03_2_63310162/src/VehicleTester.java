
public class VehicleTester {
public static void main(String[] args) {
Vehicle Mercedes = new Vehicle();
Mercedes.accelerate();
Mercedes.accelerate();
Mercedes.applyBreak();
Mercedes.accelerate();
Mercedes.applyBreak();
Mercedes.printCurrentSpeed();
}
}